function pesan(namaJasa) {

  const nomor = "6281234567890";

  const teks =
    "Halo, saya ingin memesan " + namaJasa;

  const link =
    "https://wa.me/" +
    nomor +
    "?text=" +
    encodeURIComponent(teks);

  window.open(link, "_blank");
}